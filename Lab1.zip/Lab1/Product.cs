﻿using System;

public class Product
{
    private string name;
    private decimal price;
    private int quantity;

    public Product(string name, decimal price, int quantity)
    {
        Name = name;
        Price = price;
        this.quantity = quantity;
    }

    public string Name
    {
        get => name;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Назва товару не може бути порожньою!");
            name = value;
        }
    }

    public decimal Price
    {
        get => price;
        set
        {
            if (value < 0)
                throw new ArgumentException("Ціна не може бути менше 0!");
            price = value;
        }
    }

    public int Quantity => quantity;

    public decimal TotalValue => price * quantity;

    public void Restock(int amount)
    {
        if (amount <= 0)
            throw new ArgumentException("Кількість для постачання повинна бути більше 0!");
        quantity += amount;
    }

    public void Sell(int amount)
    {
        if (amount <= 0)
            throw new ArgumentException("Кількість для продажу повинна бути більше 0!");
        if (amount > quantity)
        {
            Console.WriteLine("Недостатньо товару на складі!");
            return;
        }
        quantity -= amount;
    }

    public string GetInfo()
    {
        return $"Товар: {name}, Ціна: {price} грн, Кількість: {quantity}, Загальна вартість: {TotalValue} грн";
    }
}